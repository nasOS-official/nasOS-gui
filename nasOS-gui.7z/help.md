### Help
#### How to connect to ftp server?
Download filezilla and type ip of this server and port 22.

#### How to shutdown?
1. Click the "About this PC" tab.
2. Click the shutdown button.

<img src="./help_assets/shutdown.png" alt="Shutdown" width="40%"/> 
