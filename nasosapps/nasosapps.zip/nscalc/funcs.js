 //Make the DIV element draggagle:
   document.getElementById("calcapp").style.top = "50%";
   document.getElementById("calcapp").style.left = "50%";
   document.getElementById("calcapp").style.transform = "translate(-50%, -50%)";
   let calcapplication =  document.getElementById("calcapp");
   let pos1, pos2, pos3, pos4;

calcappheader.onmousedown = function() {
  document.onmousemove = () => {
    pos1 = pos3 - window.event.clientX;
    pos2 = pos4 - window.event.clientY;
    pos3 = window.event.clientX;
    pos4 = window.event.clientY;
    calcapplication.style.top = (calcapplication.offsetTop - pos2) + "px";
    calcapplication.style.left = (calcapplication.offsetLeft - pos1) + "px";
   }
}
calcappheader.onmouseup = () => {
  document.onmousemove = null;
}