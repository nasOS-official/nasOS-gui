# nasOS gui
This is a new graphical shell for linux! It is written using js.

# Testing
```bash
sudo pacman -Syu  nodejs npm electron
git clone https://github.com/nasOS-official/nasOS-gui
cd nasOS-gui
npm install
npm start
```